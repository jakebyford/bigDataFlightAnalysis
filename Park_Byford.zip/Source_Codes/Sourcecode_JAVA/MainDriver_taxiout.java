
import java.io.File;
import java.io.FileWriter;
import java.util.TreeSet;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;



public class ResultPairLow implements Comparable<ResultPairLow>  {
	

	double avg;
	String key;

	ResultPairLow(double avg, String key) {
		this.avg = avg;
		this.key = key;
	}

	@Override
	public int compareTo(ResultPairLow resultPairLow) {
		if (this.avg >= resultPairLow.avg) {
			return 1;
		} else {
			return -1;
		}
	}
}


public class MyReducerTaxiOut extends Reducer<Text, IntWritable,Text,DoubleWritable>{
	TreeSet<ResultPairHigh> sortedOutputHigh = new TreeSet<>();
	TreeSet<ResultPairLow> sortedOutputLow = new TreeSet<>();
	

	@Override
	protected void reduce(Text key, Iterable<IntWritable> value,
			Reducer<Text, IntWritable, Text, DoubleWritable>.Context con)
			throws IOException, InterruptedException {
		double sum = 0;
		int i = 0;
		for (IntWritable val : value) {
			sum += (double)val.get();
			i++;
		}
		double average = sum/i;
		
		sortedOutputHigh.add(new ResultPairHigh(average, key.toString()));
		if (sortedOutputHigh.size() > 3) {
			sortedOutputHigh.pollLast();
		}
		
		sortedOutputLow.add(new ResultPairLow(average, key.toString()));
		if (sortedOutputLow.size() > 3) {
			sortedOutputLow.pollLast();
		}
		
		

		
		//con.write(key, new DoubleWritable(average));		
	}
	protected void cleanup(Context context)
            throws IOException,
            InterruptedException {
		context.write(new Text("Airports with Longest Taxi Out Time are:"), new DoubleWritable());
		
		while(!sortedOutputHigh.isEmpty()){
			ResultPairHigh p1= sortedOutputHigh.pollFirst();
			context.write(new Text(p1.key), new DoubleWritable(p1.avg));
		}
		context.write(new Text(), new DoubleWritable());
		context.write(new Text("Airports with Shortest Taxi Out Time are:"), new DoubleWritable());
		
		while(!sortedOutputLow.isEmpty()){
			ResultPairLow p2= sortedOutputLow.pollFirst();
			context.write(new Text(p2.key), new DoubleWritable(p2.avg));
		}
	}
}


public class MyMapperTaxiOut extends Mapper<LongWritable, Text, Text, IntWritable>{
	  @Override
	  protected void map(LongWritable key, Text value, Context con)
	  throws IOException, InterruptedException {
	        	
	        String[] splitData = value.toString().split(",");
	        if(!splitData[0].equalsIgnoreCase("year") && !splitData[17].equals("NA") && !splitData[20].equals("NA")){
	        con.write(new Text(splitData[17]), new IntWritable(Integer.parseInt(splitData[20])));
	        }
	  }
}




public class ResultPairHigh implements Comparable<ResultPairHigh>  {
	

	double avg;
	String key;

	ResultPairHigh(double avg, String key) {
		this.avg = avg;
		this.key = key;
	}

	@Override
	public int compareTo(ResultPairHigh resultPairHigh) {
		if (this.avg <= resultPairHigh.avg) {
			return 1;
		} else {
			return -1;
		}
	}
}












public class MainDriver_taxiout {
	public static void main(String[] args)throws Exception{
        Configuration conf = new Configuration();
        Job job = new Job(conf, "Average Taxi Out time");
        job.setJarByClass(MyDriver.class);
        job.setMapperClass(MyMapperTaxiOut.class);
        job.setReducerClass(MyReducerTaxiOut.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        FileInputFormat.setInputPaths(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);         
    }
}