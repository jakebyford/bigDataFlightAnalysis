
import java.io.File;
import java.io.FileWriter;
import java.util.TreeSet;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;







    public class MapperCancel extends Mapper<LongWritable, Text, Text, IntWritable>{
        @Override
        protected void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {
            String[] splitData = value.toString().split(",");
        
            if(splitData[21].equals("1") && !splitData[22].equals("NA")){
            con.write(new Text(splitData[22]), new IntWritable(1) );
            }
        }
    }









public class ReducerCancel extends Reducer<Text, IntWritable,Text, IntWritable>{

	TreeMap<Integer, String> sort = new TreeMap();
	@Override
	protected void reduce(Text key, Iterable<IntWritable> value,
			Reducer<Text, IntWritable, Text, IntWritable>.Context con)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		int sum = 0;
		for (IntWritable val : value) {
			sum += val.get();
		}
		sort.put(sum, key.toString());
		
	}
	
	
	protected void cleanup(Context con){
		int sum = sort.lastKey();
		String key = sort.get(sum);
		if(key.equalsIgnoreCase("a")){
			try {
				con.write(new Text("CARRIER"), new IntWritable(sum));
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		else if(key.toString().equalsIgnoreCase("B")){
			try {
				con.write(new Text("WEATHER"), new IntWritable(sum));
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		else if(key.toString().equalsIgnoreCase("C")){
			try {
				con.write(new Text("NAS"), new IntWritable(sum));
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		else if(key.toString().equalsIgnoreCase("D")){
			try {
				con.write(new Text("SECURITY"), new IntWritable(sum));
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	}















public class MainDriver_cancellation {
	
	
	public static void main(String[] args)throws Exception{
        Configuration conf = new Configuration();
        Job job = new Job(conf, "Flight Cancellation");
        job.setJarByClass(MyDriver.class);
        job.setMapperClass(MapperCancel.class);
        job.setReducerClass(ReducerCancel.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.setInputPaths(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
        
       
            
    }
}
