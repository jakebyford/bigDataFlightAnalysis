
import java.io.File;
import java.io.FileWriter;
import java.util.TreeSet;
import java.io.IOException;
import java.util.TreeSet;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.io.Text;


public class MyMapperProb extends Mapper<LongWritable, Text, Text, IntWritable>{
	  @Override
	  protected void map(LongWritable key, Text value, Context con)
	  throws IOException, InterruptedException {
	        	
	        String[] splitData = value.toString().split(",");
	        if(!splitData[0].equalsIgnoreCase("year") && splitData[14].equals("0") && splitData[15].equals("0")){
		        con.write(new Text(splitData[8]+" "+"y"), new IntWritable(1));
		  }
		  con.write(new Text(splitData[8]+ " " + "*"), new IntWritable(1));
	  }
}





public class ResultPair implements Comparable<ResultPair>  {
	

	double prob;
	String key;
	String value;

	ResultPair(double prob, String key, String value) {
		this.prob = prob;
		this.key = key;
		this.value = value;
	}

	@Override
	public int compareTo(ResultPair resultPair) {
		if (this.prob <= resultPair.prob) {
			return 1;
		} else {
			return -1;
		}
	}
}






public class MyReducerProb extends Reducer<Text, IntWritable,Text, Text>{
	
	DoubleWritable count = new DoubleWritable();
	DoubleWritable relCount = new DoubleWritable();
	Text word = new Text("");
	TreeSet<ResultPair> sortedOutput_temp = new TreeSet<>();
	TreeSet<ResultPair1> sortedOutput = new TreeSet<>();
	
	@Override
	protected void reduce(Text key, Iterable<IntWritable> value,
			Reducer<Text, IntWritable, Text, Text>.Context con) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
	
		String[] keyy = key.toString().split(" ");
		
		if(keyy[1].equals("*")){
			if(keyy[0].equals(word.toString())){
				count.set(count.get() + getCount(value));
			}
			else{
				word.set(keyy[0]);
				count.set(0);
				count.set(getCount(value));
			}
		}
		
		else if(keyy[1].equals("y")){
			double cnt = getCount(value);
			relCount.set((double)cnt / count.get());
			Double rel = relCount.get();
			sortedOutput_temp.add(new ResultPair(rel, key.toString(), word.toString()));
			if (sortedOutput_temp.size() > 3) {
				sortedOutput_temp.pollLast();
			}
			
			sortedOutput.add(new ResultPair1(rel, key.toString(), word.toString()));
			if (sortedOutput.size() > 3) {
				sortedOutput.pollLast();
			}
			}
		}
	
	private double getCount(Iterable<IntWritable> values) {
		double count = 0;
		for (IntWritable value : values) {
			count += value.get();
		}
		return count;
	}
	
	protected void cleanup(Context context)
            throws IOException,
            InterruptedException {
		context.write(new Text("Airlines with Higher Probability:"), new Text());
		while(!sortedOutput_temp.isEmpty()){
			ResultPair p1= sortedOutput_temp.pollFirst();
			context.write(new Text(p1.key.split(" ")[0]), new Text(Double.toString(p1.prob)));
		}
		context.write(new Text("Airlines with Lowest Probability:"), new Text());
		while(!sortedOutput.isEmpty()){
			ResultPair1 p2= sortedOutput.pollFirst();
			context.write(new Text(p2.key.split(" ")[0]), new Text(Double.toString(p2.prob)));
		}
	}
	
	
}



public class ResultPair1 implements Comparable<ResultPair1>  {
	

	double prob;
	String key;
	String value;

	ResultPair1(double prob, String key, String value) {
		this.prob = prob;
		this.key = key;
		this.value = value;
	}

	@Override
	public int compareTo(ResultPair1 resultPair) {
		if (this.prob >= resultPair.prob) {
			return 1;
		} else {
			return -1;
		}
	}
}




public class MainDriver_prob {
	public static void main(String[] args)throws Exception{
        Configuration conf = new Configuration();
        Job job = new Job(conf, "Prob");
        job.setJarByClass(MyDriver.class);
        job.setMapperClass(MyMapperProb.class);
        job.setReducerClass(MyReducerProb.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.setInputPaths(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);         
    }
}